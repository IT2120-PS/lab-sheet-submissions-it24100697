setwd("C:\\Users\\it24100697\\Desktop\\PS_Lab_5")

data<-read.table("Data.txt",header=TRUE,sep=",")

fix(data)

attach(data)

names(data)<-c("X1","X2")

attach(data)


#Draw a histogram for the above data.
hist(X2,main="Histogram for number of shareholders") 

# Draw a histogram using seven classes where the lower limit is 130 and an upper
#limit of 270.
histogram<-hist(X2,main="Histogram for number of shareholders", breaks=seq(130,270,length=8),right=FALSE)


# Construct the frequency distribution
breaks<- round(histogram$breaks)
freq<- histogram$counts
mids<-histogram$mids

classes <-c()

for(i in 1:length(breaks)-1){
  classes[i]<-paste0("[",breaks[i],",",breaks[i+1],")")
}

cbind(Classes=classes,frequency=freq)


#Portray the distribution in the form of a frequency polygon.

lines(mids,freq)

plot(mids,freq,type='l', main="Frequency Ploygon for shareholders",xlab="Shareholders",ylab="Frequency",ylim=c(0,max(freq)))


#Portray the distribution in a cumulative frequency polygon (ogive).
cum.freq<-cumsum(freq)

new<-c()

for(i in 1: length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}

plot(breaks, new,type='l',
     main="Cumalative Frequency Ploygon for shareholders",
     xlab="Shareholders",
     ylab="Cumalative Frequency",
     ylim=c(0,max(cum.freq)))

cbind(Upper=breaks,CumFreq=new)



