#1. Import the dataset (’Exercise.txt’) into R and store it in a data frame called
”branch data”.

setwd("C:\\Users\\it24100697\\Desktop\\IT24100697")
branch_data<-read.table("Exercise.txt",header=TRUE,sep=" ")


#2. Identify the variable type and scale of measurement for each variable.
# sales--->Quantitative
#Advertising--->Quantitative
#Years---> Quantitative
str(branch_data)

#3. Obtain boxplot for sales and interpret the shape of the sales distribution.
boxplot(X1,main="Box plot for Sales",ylab="Sales")


#4. Calculate the five number summary and IQR for advertising variable
fivenum(X2)
IQR(X2)

#5. Write an R function to find the outliers in a numeric vector and check for outliers
in years variables.
get.outliers<-function(z){
  q1<-quantile(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  
  print(paste("Upper Bound =",ub))
  print(paste("Lower Bound=",lb))
  print(paste("outliers:",paste(sort(z[z<lb|z>ub]),collapse = ",")))
}
get.outliers(X3)

  
